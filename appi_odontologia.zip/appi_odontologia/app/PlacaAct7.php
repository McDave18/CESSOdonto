<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PLacaAct7 extends Model
{
	protected $table = 'placaact7';// aqui se pone el nombre de la tabla´

	//aqui crear la conexion con la tabla llamalo en base a la table crea varios de esto en base a las tablas
}