<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sesiones extends Model
{
	protected $table = 'controlplacadb';// 


	//aqui crear la conexion con la tabla llamalo en base a la table crea varios de esto en base a las tablas
}