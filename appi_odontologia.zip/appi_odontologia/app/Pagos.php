<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pagos extends Model
{
	protected $table = 'control_pagos';// 


	//aqui crear la conexion con la tabla llamalo en base a la table crea varios de esto en base a las tablas
}