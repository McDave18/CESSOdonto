<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Odontograma extends Model
{
	protected $table = 'odontograma';// aqui se pone el nombre de la tabla´
	//ok

	//aqui crear la conexion con la tabla llamalo en base a la table crea varios de esto en base a las tablas
}