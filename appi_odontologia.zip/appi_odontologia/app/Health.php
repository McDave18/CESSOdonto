<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Health extends Model
{
	protected $table = 'healthhistory';// 
	

	//aqui crear la conexion con la tabla llamalo en base a la table crea varios de esto en base a las tablas
}