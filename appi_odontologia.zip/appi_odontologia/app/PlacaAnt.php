<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PLacaAnt extends Model
{
	protected $table = 'placaant';// aqui se pone el nombre de la tabla´

	//aqui crear la conexion con la tabla llamalo en base a la table crea varios de esto en base a las tablas
}