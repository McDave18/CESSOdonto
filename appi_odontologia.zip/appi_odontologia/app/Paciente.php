<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Paciente extends Model
{
	protected $table = 'datos_personales';// aqui se pone el nombre de la tabla
	//ok

	//aqui crear la conexion con la tabla llamalo en base a la table crea varios de esto en base a las tablas
}