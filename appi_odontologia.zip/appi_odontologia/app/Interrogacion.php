<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Interrogacion extends Model
{
	// protected $table = 'exploracion';// aqui se pone el nombre de la tabla aqui deberia de ir la otra tabla que es....interrogacion
	protected $table = 'interrogacion';

	//aqui crear la conexion con la tabla llamalo en base a la table crea varios de esto en base a las tablas
}